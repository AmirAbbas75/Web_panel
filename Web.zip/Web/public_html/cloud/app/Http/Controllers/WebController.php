<?php

namespace App\Http\Controllers;

use App\Helpers\Post;
use Illuminate\Routing\ResponseFactory;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\Artisan;
use PHPUnit\Framework\ExpectationFailedException;
use Symfony\Component\HttpKernel\Exception\HttpException;


class WebController extends Controller
{

    public function dispach(Request $request)
    {


        $url = $request->get("url");

	//$url = "dbapache/cloud/public/api/login";

        $result = Post::send($url,$request->post());
       
            return response()->json($result, 200);


    }


}
