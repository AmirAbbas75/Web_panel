<?php

namespace App\Helpers;

class Post
{
     public static Function send($url, $data)
    {
        $ch = curl_init($url);

        curl_setopt_array($ch, array(
            CURLOPT_POST => TRUE,
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
            CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_UNICODE )
        ));
        $result = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($result);
    }

}