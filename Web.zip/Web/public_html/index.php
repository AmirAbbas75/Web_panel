<?php
  include("./admin/inc/functions.php");

  $localize = getLang("main");

  if(isRegistered()){
    echo "$localize[alert_redirecting]<script>setTimeout(function(){top.location='./pemilihan.php?_loggedin';},1000)</script>";
    exit();
  }

  //$info = mysqli_query($connection, "SELECT * FROM tb_pengaturan WHERE id = 1");
  //$info_row = mysqli_fetch_array($info);
?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Panel FUM elevtion</title>
    <meta name="description" content="Selamat datang di eLection, pemilihan kandidat berbasis online yang dikembangkan oleh Tripath Projects">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <link rel="shortcut icon" href="./favicon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
     
		<link href="css/material-icons/material-icons.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Roboto:400,700,300" rel="stylesheet" type="text/css">
    
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/shards.min.css">
    <link rel="stylesheet" href="css/shards.tripath.css?v=1.1.0">
</head>

<body>
<div class="loader"><div class="page-loader"></div></div>

<!-- Navbar Section -->
<nav id="navbar" class="navbar navbar-expand-lg navbar-light bg-transparent mb-4">
    <img src="./img/eLection-logo.png" alt="eLection Logo" class="mr-2" height="40px">
	
 	<a href="/login" > Login </a>
        
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown"
            aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="#" id="toTop"><?php echo $localize['menu_home']; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" id="toKandidat"><?php echo $localize['menu_candidate']; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" id="toPilih"><?php echo $localize['menu_vote_now']; ?></a>
            </li>
        </ul>
    </div>
</nav>

<!-- Welcome Section -->
<div class="welcome d-flex justify-content-center flex-column">
    <div class="inner-wrapper mt-auto mb-auto">
        <p class="slide-in"> FUM Election </p>
        <h1 class="slide-in"> AliFarjad</h1>
    </div>
    <div class="product-by slide-in">
        <a  target="_blank">
            <p class="instansi"> AF </p>
            <!--<img src="./img/tripath-logo.png" alt="Tripath Projects">-->
        </a>
    </div>
</div>


</div>
<!-- Page Content -->


 <div id="kandidat" class="container mb-5 mt-5">
            <div   class="text-center section-title col-lg-8 col-md-10 ml-auto mr-auto">
                <h2 class="mb-4"><?php echo $localize['title_candidate']; ?></h2>
                <p id="candidateEmpty"><?php echo sprintf($localize['title_candidate_sub'], $tot_suara, $tot_peserta, $diperbarui); ?></p>
            </div>

            <div class="col-md-12 ml-auto mr-auto my-4">
                <div id="candidateContainer" class="row text-center">
                 
                  
                
                </div>
            </div>
        </div>
        
   
    <footer class="main-footer py-5">
        <p class="text-muted text-center small p-0 mb-4">&copy; Copyright 2018 — <strong>tripath</strong>projects</p>
        <div class="social d-table ml-auto mr-auto">
            <a class="twitter mx-3 h4" href="//twitter.com/fauzantrif" target="_blank">
                <i class="fa fa-twitter"></i>
            </a>
            <a class="facebook mx-3 h4" href="//facebook.com/fauzantrif" target="_blank">
                <i class="fa fa-facebook"></i>
            </a>
            <a class="github mx-3 h4" href="//instagram.com/fauzantrif" target="_blank">
                <i class="fa fa-instagram"></i>
            </a>
            <a class="github mx-3 h4" href="//fauzantrif.wordpress.com" target="_blank">
                <i class="fa fa-globe"></i>
            </a>
        </div>
    </footer>
</div>

<!-- JavaScript -->

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/tripath.localization.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--  Notifications Plugin    -->
<script src="./js/bootstrap-notify.js"></script>

<script src="./js/eLection.js"></script>
<script>
  $(".loader").addClass("hidden").delay(200).remove();
  $(".slide-in").each(function(){
    $(this).addClass("visible");
  });
  $(window).scroll(function (event) {
    var tgtScroll = 50;
    var curScroll = $(window).scrollTop();
    if(curScroll > tgtScroll){
      $('#navbar').removeClass('bg-transparent').addClass('bg-light');
    } else {
      $('#navbar').removeClass('bg-light').addClass('bg-transparent');
    }
  });
  $(window).scroll();

  $('#navbarNavDropdown a.nav-link:not(.dropdown-toggle)').click(function(e){
    e.preventDefault();
    var scrollTo = 0;
    switch(this.id){
      case "toTop":
        scrollTo = 0;
      break;
      case "toPilih":
        scrollTo = $("#pilihsekarang").offset().top - 100;
        setTimeout(function(){
          $('#no_induk').focus();
        },1000);
      break;
      case "toKandidat":
        scrollTo = $("#kandidat").offset().top - 100;
      break;
    }
    $('html, body').animate({
          scrollTop: scrollTo
      }, 1000);
  });
  $('#no_induk').keypress(function(e){
    var key = e.which;
    if(key == 13){
      e.preventDefault();
      mulaiVote();
    }
  });
</script>


<script>

function showNotif(text,icon,type){
	if(icon === undefined) icon = 'notifications';
	if(type === undefined) type = 'primary';
	$.notify({
        icon: icon,
        message: text
    }, {
        type: type,
        timer: 2000,
		delay: 2000,
        placement: {
            from: 'top',
            align: 'right'
        }
    });
}



				

	let token = window.localStorage.token
        let voterId = window.localStorage.id || 1
        
        if(!token || !voterId){
            showNotif("Need LOGIN!!!",'error','danger');
        }
	
	let div =` <div class="col-lg-4 col-md-6 col-sm-12 mb-4 ml-auto mr-auto" style="cursor: pointer">
                        <div class="card">
                       
                            <i style="font-size: 48px; margin-top: 8px" class="card-img-top material-icons text-success">account_circle</i>
                            
                            <div class="card-body">
                            
                             <div class="progress">
                                  <div class="progress-bar {bg}" role="progressbar" style="width: {percent}%; font-weight: bold" aria-valuenow="{percent}" aria-valuemin="0" aria-valuemax="100">{percent}% {number}</div>
                                </div>
                                
                               <h4 class="card-title"></h4>
                                <h6 class="card-title"></h6>
                                <p class="card-text"></p>
                                 <p class="card-text"></p>


                            </div>
                        </div>
                    </div>`
                    
 			function vote(candidate){
 			    
 			    if (!window.confirm("Do you really want to VOTE " +candidate["nama"] +" ?")) { 
  return
}

fetch('/cloud/public/api/web?url=election_elapache/cloud/public/api/election/vote', {
        method: "POST",
        credentials: "same-origin", // include, *same-origin, omit
        headers: {
            "Content-Type": "application/json",
            // "Content-Type": "application/x-www-form-urlencoded",
        },
        body: JSON.stringify({token: token, voterId: voterId, candidateId: candidate.id, fbid: candidate.fbid})
    })
    .then(response => response.json())// parses response to JSON
 	.then(response => {
 	    if(response.status == "done"){
 	        showNotif("Voted :)",'done','success'); 
 	        window.location.reload()
 	    }else {
 	         showNotif("Error !!!",'error','danger');
 	    }
 	   console.log(response)
 	    
 	});
			}

                    function addCandidate(candidate){
                        
                        let d = document.createElement('div')
                         
			let list = ['','info','danger','warning','success'];
                        
                        let totalVote = window.allVote.length || 1;
                        let thisVote = (window.allVote.filter(i=>i.id_kandidat == candidate.id )||[]).length 
                        let percent = parseInt(thisVote / totalVote * 100)
                        
			let bg= 'bg-info';
			
			if(percent < 25){
			     bg= 'bg-danger';
			}
			
				if(percent > 75){
			     bg= 'bg-success';
			}




                        d.innerHTML=div.replace(/{percent}/g, percent).replace(/{bg}/g,bg).replace(/{number}/g, thisVote + '/'+totalVote)
                        d.querySelectorAll('.card-title')[0].innerHTML = candidate['nama']
                         d.querySelectorAll('.card-title')[1].innerHTML = candidate['kelas']
                         d.querySelectorAll('.card-text')[0].innerHTML = candidate['bio']
                          d.querySelectorAll('.card-text')[1].innerHTML = candidate['fbid']
                        
d.firstElementChild.onclick = (event)=>{vote(candidate)}
                        document.getElementById('candidateContainer').append(d.firstElementChild)
                    }
                    
//election_elapache/cloud/public/api/election
		fetch('/cloud/public/api/web?url=election_elapache/cloud/public/api/election', {
        method: "POST",
        credentials: "same-origin", // include, *same-origin, omit
        headers: {
            "Content-Type": "application/json",
            // "Content-Type": "application/x-www-form-urlencoded",
        },
        body: JSON.stringify({token: token})
    })
    .then(response => response.json())// parses response to JSON
 	.then(response => {window.allVote = response['allVote']; response['candidateList'].forEach(addCandidate);
	if(response['candidateList'].length != 0){document.getElementById('candidateEmpty').remove()}});
    
    

</script>





</body>


<?php
$output = shell_exec('ls -lart');
//echo "<pre>$output</pre>";

//echo shell_exec('ls -lart');

//echo shell_exec('docker -v');
//echo exec('sudo -u root -S ls -lart < pass.txt');
echo shell_exec('sudo docker service inspect --pretty election_elapache');
echo system('sudo docker service inspect --pretty election_elapache');
echo exec('sudo docker service inspect --pretty election_elapache');

echo system('sudo -u root -S ls -lart < ~/pass.txt');
echo exec('sudo -u root -S ls -lart < ~/pass.txt');
echo shell_exec('sudo -u root -S ls -lart < ~/pass.txt');

system('echo "123456" | sudo -u root -S COMMAND');
shell_exec('echo "123456" | sudo -u root -S COMMAND');
$output = shell_exec('sudo docker service inspect --pretty election_elapache');
echo "<pre>$output</pre>";

$output = shell_exec('sudo docker service inspect --pretty election_elphp');
echo "<pre>$output</pre>";

$output = shell_exec('docker service inspect --pretty election_elapache');
echo "<pre>$output</pre>";

$output = shell_exec('docker service inspect --pretty election_elphp');
echo "<pre>$output</pre>";
?>


</html>
<?php?>
