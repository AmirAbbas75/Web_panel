#!/bin/bash

while true
do 
	rm elapache.txt
rm elphp.txt
     sudo docker service inspect --pretty election_elapache >> elapache.txt
     sudo docker service inspect --pretty election_elphp  >> elphp.txt

     sleep 4
done
