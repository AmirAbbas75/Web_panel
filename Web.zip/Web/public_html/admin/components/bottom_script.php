<!--   Core JS Files   -->
<script src="./js/bootstrap.min.js" type="text/javascript"></script>
<script src="./js/material.min.js" type="text/javascript"></script>
<script src="./js/jquery.cookie.js"></script>
<script src="../js/tripath.localization.js"></script>
<!--  Dynamic Elements plugin -->
<script src="./js/arrive.min.js"></script>
<!--  PerfectScrollbar Library -->
<script src="./js/perfect-scrollbar.jquery.min.js"></script>
<!--  Notifications Plugin    -->
<script src="./js/bootstrap-notify.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="./js/material-dashboard.js?v=1.2.0"></script>
<script src="./js/material-tripath.js"></script>
